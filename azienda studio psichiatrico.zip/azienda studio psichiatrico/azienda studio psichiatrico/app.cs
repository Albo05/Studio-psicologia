﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace azienda_studio_psichiatrico
{
    internal class app : IComparable<app>
    {
        paz _paziente;
        doc _dottore;
        DateTime _data;
        string _arg;
        double _ore;

        public paz paziente { get { return _paziente; } set { _paziente = value; } }
        public doc dottore { get { return _dottore; } set { _dottore = value; } }
        public DateTime data { get { return _data; } set { _data = value; } }
        public string argomento { get { return _arg; } set { _arg = value; } }
        public double ore { get { return _ore; } set { _ore = value; } }

        public app(paz paziente, doc dottore, DateTime data, string arg, double ore)
        {
            this._paziente = paziente;
            this._dottore = dottore;
            this._data = data;
            this._arg = arg;
            this._ore = ore;
        }

        public int CompareTo(app other)
        {
            int confrontaData = _data.CompareTo(other.data);
            if (confrontaData != 0)
                return confrontaData;
            int confrontaOra = _ore.CompareTo(other.ore);
            if (confrontaOra != 0)
                return confrontaOra;
            return _dottore.CompareTo(other.dottore);
        }

        public static app nuovo(string stringa)
        {
            stringa = stringa.Trim();
            string[] appoggioAppuntamento = stringa.Split('*');
            return new app(paz.nuovo(appoggioAppuntamento[0]), doc.nuovo(appoggioAppuntamento[1]), Convert.ToDateTime(appoggioAppuntamento[2]), appoggioAppuntamento[3], Convert.ToDouble(appoggioAppuntamento[4]));
        }

        public override string ToString()
        {
            return $"{paziente.ToString()}*{dottore.ToString()}*{data.ToShortDateString()}*{argomento}*{ore.ToString()}".PadRight(60);
        }
    }
}
