﻿namespace azienda_studio_psichiatrico
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.dateLbl = new System.Windows.Forms.Label();
            this.clockLbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Aggiungi = new System.Windows.Forms.Panel();
            this.SeparatoreOreAggiungi = new System.Windows.Forms.Label();
            this.MinutiAggiungi = new System.Windows.Forms.TextBox();
            this.OraAggiungi = new System.Windows.Forms.TextBox();
            this.OreAggiungi = new System.Windows.Forms.Label();
            this.BottoneSalvaAggiungi = new System.Windows.Forms.Button();
            this.AppuntamentoArgomentoAggiugni = new System.Windows.Forms.Label();
            this.AppArgomentoAggiungi = new System.Windows.Forms.TextBox();
            this.GiornoSelezioneAggiungi = new System.Windows.Forms.DateTimePicker();
            this.GiornoSelezionaAggiungi = new System.Windows.Forms.Label();
            this.DottoreSelezioneAggiungi = new System.Windows.Forms.ComboBox();
            this.DotoreSelezioneAggiungi = new System.Windows.Forms.Label();
            this.InserireIbanAggiungi = new System.Windows.Forms.Label();
            this.PazienteCodiceFiscaleAggiungi = new System.Windows.Forms.TextBox();
            this.InserireCognomeAggiungi = new System.Windows.Forms.Label();
            this.PazienteCognomeAggiungi = new System.Windows.Forms.TextBox();
            this.InserireNomeAggiungi = new System.Windows.Forms.Label();
            this.PazienteNomeAggiungi = new System.Windows.Forms.TextBox();
            this.Calendario = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.VaiAppuntamenti = new System.Windows.Forms.Button();
            this.ListaAppuntamentiAggiugni = new System.Windows.Forms.Label();
            this.GiornoCalendario = new System.Windows.Forms.DateTimePicker();
            this.SelezionaGiornoCalendario = new System.Windows.Forms.Label();
            this.Appuntamento = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.InserireCognomeAppuntamento = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.PazienteCognomeAppuntamento = new System.Windows.Forms.TextBox();
            this.InserireNomeAppuntamento = new System.Windows.Forms.Label();
            this.PazienteNomeAppuntamento7 = new System.Windows.Forms.TextBox();
            this.SeparatoreOreAppuntamento = new System.Windows.Forms.Label();
            this.MinutiAppuntamento = new System.Windows.Forms.TextBox();
            this.OraAppuntamento = new System.Windows.Forms.TextBox();
            this.OreAppuntamento = new System.Windows.Forms.Label();
            this.AppuntamentoArgomentoAppuntamento = new System.Windows.Forms.Label();
            this.AppArgomentoAppuntamento = new System.Windows.Forms.TextBox();
            this.GiornoSelezioneAppuntamento = new System.Windows.Forms.DateTimePicker();
            this.GiornoSelezionaAppuntamento = new System.Windows.Forms.Label();
            this.DottoreSelezioneAppuntamento = new System.Windows.Forms.ComboBox();
            this.DottoreSelezionaAppuntamento = new System.Windows.Forms.Label();
            this.InserireIbanAppuntamento = new System.Windows.Forms.Label();
            this.PazienteIbanAppuntamento = new System.Windows.Forms.TextBox();
            this.SalvaAppuntamento = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.orologio = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Aggiungi.SuspendLayout();
            this.Calendario.SuspendLayout();
            this.Appuntamento.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.dateLbl);
            this.panel1.Controls.Add(this.clockLbl);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(663, 69);
            this.panel1.TabIndex = 0;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Red;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(614, 13);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(41, 37);
            this.button10.TabIndex = 7;
            this.button10.Text = "Exit";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(486, 13);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(92, 37);
            this.button9.TabIndex = 6;
            this.button9.Text = "Dottori";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(290, 13);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(92, 37);
            this.button8.TabIndex = 5;
            this.button8.Text = "Visualizza appuntamenti";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(388, 13);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(92, 37);
            this.button7.TabIndex = 4;
            this.button7.Text = "Modifica appuntamento";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(189, 13);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(92, 37);
            this.button6.TabIndex = 3;
            this.button6.Text = "Aggiungi appuntamento";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dateLbl
            // 
            this.dateLbl.AutoSize = true;
            this.dateLbl.Location = new System.Drawing.Point(69, 37);
            this.dateLbl.Name = "dateLbl";
            this.dateLbl.Size = new System.Drawing.Size(41, 13);
            this.dateLbl.TabIndex = 2;
            this.dateLbl.Text = "label15";
            // 
            // clockLbl
            // 
            this.clockLbl.AutoSize = true;
            this.clockLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clockLbl.Location = new System.Drawing.Point(100, 13);
            this.clockLbl.Name = "clockLbl";
            this.clockLbl.Size = new System.Drawing.Size(32, 20);
            this.clockLbl.TabIndex = 1;
            this.clockLbl.Text = "ora";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::azienda_studio_psichiatrico.Properties.Resources.User_profile_white_avatar_icon_black_circle_vector_image_png;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(62, 62);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Aggiungi
            // 
            this.Aggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.Aggiungi.Controls.Add(this.SeparatoreOreAggiungi);
            this.Aggiungi.Controls.Add(this.MinutiAggiungi);
            this.Aggiungi.Controls.Add(this.OraAggiungi);
            this.Aggiungi.Controls.Add(this.OreAggiungi);
            this.Aggiungi.Controls.Add(this.BottoneSalvaAggiungi);
            this.Aggiungi.Controls.Add(this.AppuntamentoArgomentoAggiugni);
            this.Aggiungi.Controls.Add(this.AppArgomentoAggiungi);
            this.Aggiungi.Controls.Add(this.GiornoSelezioneAggiungi);
            this.Aggiungi.Controls.Add(this.GiornoSelezionaAggiungi);
            this.Aggiungi.Controls.Add(this.DottoreSelezioneAggiungi);
            this.Aggiungi.Controls.Add(this.DotoreSelezioneAggiungi);
            this.Aggiungi.Controls.Add(this.InserireIbanAggiungi);
            this.Aggiungi.Controls.Add(this.PazienteCodiceFiscaleAggiungi);
            this.Aggiungi.Controls.Add(this.InserireCognomeAggiungi);
            this.Aggiungi.Controls.Add(this.PazienteCognomeAggiungi);
            this.Aggiungi.Controls.Add(this.InserireNomeAggiungi);
            this.Aggiungi.Controls.Add(this.PazienteNomeAggiungi);
            this.Aggiungi.Location = new System.Drawing.Point(13, 88);
            this.Aggiungi.Name = "Aggiungi";
            this.Aggiungi.Size = new System.Drawing.Size(660, 392);
            this.Aggiungi.TabIndex = 1;
            this.Aggiungi.Visible = false;
            // 
            // SeparatoreOreAggiungi
            // 
            this.SeparatoreOreAggiungi.AutoSize = true;
            this.SeparatoreOreAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeparatoreOreAggiungi.Location = new System.Drawing.Point(569, 256);
            this.SeparatoreOreAggiungi.Name = "SeparatoreOreAggiungi";
            this.SeparatoreOreAggiungi.Size = new System.Drawing.Size(13, 18);
            this.SeparatoreOreAggiungi.TabIndex = 18;
            this.SeparatoreOreAggiungi.Text = ":";
            // 
            // MinutiAggiungi
            // 
            this.MinutiAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.MinutiAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MinutiAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinutiAggiungi.Location = new System.Drawing.Point(587, 254);
            this.MinutiAggiungi.Name = "MinutiAggiungi";
            this.MinutiAggiungi.Size = new System.Drawing.Size(34, 24);
            this.MinutiAggiungi.TabIndex = 17;
            // 
            // OraAggiungi
            // 
            this.OraAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.OraAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OraAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OraAggiungi.Location = new System.Drawing.Point(529, 254);
            this.OraAggiungi.Name = "OraAggiungi";
            this.OraAggiungi.Size = new System.Drawing.Size(34, 24);
            this.OraAggiungi.TabIndex = 16;
            // 
            // OreAggiungi
            // 
            this.OreAggiungi.AutoSize = true;
            this.OreAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OreAggiungi.Location = new System.Drawing.Point(559, 233);
            this.OreAggiungi.Name = "OreAggiungi";
            this.OreAggiungi.Size = new System.Drawing.Size(33, 18);
            this.OreAggiungi.TabIndex = 15;
            this.OreAggiungi.Text = "Ore";
            // 
            // BottoneSalvaAggiungi
            // 
            this.BottoneSalvaAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.BottoneSalvaAggiungi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BottoneSalvaAggiungi.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BottoneSalvaAggiungi.Location = new System.Drawing.Point(281, 349);
            this.BottoneSalvaAggiungi.Name = "BottoneSalvaAggiungi";
            this.BottoneSalvaAggiungi.Size = new System.Drawing.Size(100, 23);
            this.BottoneSalvaAggiungi.TabIndex = 14;
            this.BottoneSalvaAggiungi.Text = "Aggiungi";
            this.BottoneSalvaAggiungi.UseVisualStyleBackColor = false;
            this.BottoneSalvaAggiungi.Click += new System.EventHandler(this.BottoneSalvaAggiungi_Click);
            // 
            // AppuntamentoArgomentoAggiugni
            // 
            this.AppuntamentoArgomentoAggiugni.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppuntamentoArgomentoAggiugni.Location = new System.Drawing.Point(23, 211);
            this.AppuntamentoArgomentoAggiugni.Name = "AppuntamentoArgomentoAggiugni";
            this.AppuntamentoArgomentoAggiugni.Size = new System.Drawing.Size(137, 40);
            this.AppuntamentoArgomentoAggiugni.TabIndex = 13;
            this.AppuntamentoArgomentoAggiugni.Text = "Argomento dell\'appuntamento";
            this.AppuntamentoArgomentoAggiugni.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // AppArgomentoAggiungi
            // 
            this.AppArgomentoAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.AppArgomentoAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AppArgomentoAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppArgomentoAggiungi.Location = new System.Drawing.Point(166, 209);
            this.AppArgomentoAggiungi.Multiline = true;
            this.AppArgomentoAggiungi.Name = "AppArgomentoAggiungi";
            this.AppArgomentoAggiungi.Size = new System.Drawing.Size(338, 116);
            this.AppArgomentoAggiungi.TabIndex = 12;
            // 
            // GiornoSelezioneAggiungi
            // 
            this.GiornoSelezioneAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiornoSelezioneAggiungi.Location = new System.Drawing.Point(453, 148);
            this.GiornoSelezioneAggiungi.MinimumSize = new System.Drawing.Size(154, 24);
            this.GiornoSelezioneAggiungi.Name = "GiornoSelezioneAggiungi";
            this.GiornoSelezioneAggiungi.Size = new System.Drawing.Size(154, 24);
            this.GiornoSelezioneAggiungi.TabIndex = 11;
            // 
            // GiornoSelezionaAggiungi
            // 
            this.GiornoSelezionaAggiungi.AutoSize = true;
            this.GiornoSelezionaAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiornoSelezionaAggiungi.Location = new System.Drawing.Point(408, 153);
            this.GiornoSelezionaAggiungi.Name = "GiornoSelezionaAggiungi";
            this.GiornoSelezionaAggiungi.Size = new System.Drawing.Size(39, 18);
            this.GiornoSelezionaAggiungi.TabIndex = 10;
            this.GiornoSelezionaAggiungi.Text = "Data";
            // 
            // DottoreSelezioneAggiungi
            // 
            this.DottoreSelezioneAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DottoreSelezioneAggiungi.FormattingEnabled = true;
            this.DottoreSelezioneAggiungi.Location = new System.Drawing.Point(166, 148);
            this.DottoreSelezioneAggiungi.Name = "DottoreSelezioneAggiungi";
            this.DottoreSelezioneAggiungi.Size = new System.Drawing.Size(236, 26);
            this.DottoreSelezioneAggiungi.TabIndex = 8;
            // 
            // DotoreSelezioneAggiungi
            // 
            this.DotoreSelezioneAggiungi.AutoSize = true;
            this.DotoreSelezioneAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DotoreSelezioneAggiungi.Location = new System.Drawing.Point(20, 153);
            this.DotoreSelezioneAggiungi.Name = "DotoreSelezioneAggiungi";
            this.DotoreSelezioneAggiungi.Size = new System.Drawing.Size(140, 18);
            this.DotoreSelezioneAggiungi.TabIndex = 7;
            this.DotoreSelezioneAggiungi.Text = "Selezionare Dottore";
            // 
            // InserireIbanAggiungi
            // 
            this.InserireIbanAggiungi.AutoSize = true;
            this.InserireIbanAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireIbanAggiungi.Location = new System.Drawing.Point(64, 95);
            this.InserireIbanAggiungi.Name = "InserireIbanAggiungi";
            this.InserireIbanAggiungi.Size = new System.Drawing.Size(167, 18);
            this.InserireIbanAggiungi.TabIndex = 5;
            this.InserireIbanAggiungi.Text = "Codice Fiscale Paziente";
            // 
            // PazienteCodiceFiscaleAggiungi
            // 
            this.PazienteCodiceFiscaleAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteCodiceFiscaleAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteCodiceFiscaleAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteCodiceFiscaleAggiungi.Location = new System.Drawing.Point(237, 93);
            this.PazienteCodiceFiscaleAggiungi.Name = "PazienteCodiceFiscaleAggiungi";
            this.PazienteCodiceFiscaleAggiungi.Size = new System.Drawing.Size(370, 24);
            this.PazienteCodiceFiscaleAggiungi.TabIndex = 4;
            // 
            // InserireCognomeAggiungi
            // 
            this.InserireCognomeAggiungi.AutoSize = true;
            this.InserireCognomeAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireCognomeAggiungi.Location = new System.Drawing.Point(312, 28);
            this.InserireCognomeAggiungi.Name = "InserireCognomeAggiungi";
            this.InserireCognomeAggiungi.Size = new System.Drawing.Size(135, 18);
            this.InserireCognomeAggiungi.TabIndex = 3;
            this.InserireCognomeAggiungi.Text = "Cognome Paziente";
            // 
            // PazienteCognomeAggiungi
            // 
            this.PazienteCognomeAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteCognomeAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteCognomeAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteCognomeAggiungi.Location = new System.Drawing.Point(453, 26);
            this.PazienteCognomeAggiungi.Name = "PazienteCognomeAggiungi";
            this.PazienteCognomeAggiungi.Size = new System.Drawing.Size(154, 24);
            this.PazienteCognomeAggiungi.TabIndex = 2;
            // 
            // InserireNomeAggiungi
            // 
            this.InserireNomeAggiungi.AutoSize = true;
            this.InserireNomeAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireNomeAggiungi.Location = new System.Drawing.Point(50, 28);
            this.InserireNomeAggiungi.Name = "InserireNomeAggiungi";
            this.InserireNomeAggiungi.Size = new System.Drawing.Size(110, 18);
            this.InserireNomeAggiungi.TabIndex = 1;
            this.InserireNomeAggiungi.Text = "Nome Paziente";
            // 
            // PazienteNomeAggiungi
            // 
            this.PazienteNomeAggiungi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteNomeAggiungi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteNomeAggiungi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteNomeAggiungi.Location = new System.Drawing.Point(166, 26);
            this.PazienteNomeAggiungi.Name = "PazienteNomeAggiungi";
            this.PazienteNomeAggiungi.Size = new System.Drawing.Size(135, 24);
            this.PazienteNomeAggiungi.TabIndex = 0;
            // 
            // Calendario
            // 
            this.Calendario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.Calendario.Controls.Add(this.button11);
            this.Calendario.Controls.Add(this.comboBox2);
            this.Calendario.Controls.Add(this.label14);
            this.Calendario.Controls.Add(this.VaiAppuntamenti);
            this.Calendario.Controls.Add(this.ListaAppuntamentiAggiugni);
            this.Calendario.Controls.Add(this.GiornoCalendario);
            this.Calendario.Controls.Add(this.SelezionaGiornoCalendario);
            this.Calendario.Location = new System.Drawing.Point(13, 88);
            this.Calendario.Name = "Calendario";
            this.Calendario.Size = new System.Drawing.Size(660, 392);
            this.Calendario.TabIndex = 2;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button11.Location = new System.Drawing.Point(499, 186);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(109, 23);
            this.button11.TabIndex = 20;
            this.button11.Text = "Vai (dottore)";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(424, 6);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(220, 26);
            this.comboBox2.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(292, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 18);
            this.label14.TabIndex = 19;
            this.label14.Text = "Seleziona Medico";
            // 
            // VaiAppuntamenti
            // 
            this.VaiAppuntamenti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.VaiAppuntamenti.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.VaiAppuntamenti.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.VaiAppuntamenti.Location = new System.Drawing.Point(499, 153);
            this.VaiAppuntamenti.Name = "VaiAppuntamenti";
            this.VaiAppuntamenti.Size = new System.Drawing.Size(109, 23);
            this.VaiAppuntamenti.TabIndex = 18;
            this.VaiAppuntamenti.Text = "Vai (data)";
            this.VaiAppuntamenti.UseVisualStyleBackColor = false;
            this.VaiAppuntamenti.Click += new System.EventHandler(this.VaiAppuntamenti_Click);
            // 
            // ListaAppuntamentiAggiugni
            // 
            this.ListaAppuntamentiAggiugni.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ListaAppuntamentiAggiugni.Location = new System.Drawing.Point(6, 33);
            this.ListaAppuntamentiAggiugni.Name = "ListaAppuntamentiAggiugni";
            this.ListaAppuntamentiAggiugni.Size = new System.Drawing.Size(441, 339);
            this.ListaAppuntamentiAggiugni.TabIndex = 16;
            // 
            // GiornoCalendario
            // 
            this.GiornoCalendario.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiornoCalendario.Location = new System.Drawing.Point(132, 6);
            this.GiornoCalendario.MinimumSize = new System.Drawing.Size(154, 24);
            this.GiornoCalendario.Name = "GiornoCalendario";
            this.GiornoCalendario.Size = new System.Drawing.Size(154, 24);
            this.GiornoCalendario.TabIndex = 15;
            // 
            // SelezionaGiornoCalendario
            // 
            this.SelezionaGiornoCalendario.AutoSize = true;
            this.SelezionaGiornoCalendario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelezionaGiornoCalendario.Location = new System.Drawing.Point(3, 9);
            this.SelezionaGiornoCalendario.Name = "SelezionaGiornoCalendario";
            this.SelezionaGiornoCalendario.Size = new System.Drawing.Size(123, 18);
            this.SelezionaGiornoCalendario.TabIndex = 0;
            this.SelezionaGiornoCalendario.Text = "Seleziona Giorno";
            // 
            // Appuntamento
            // 
            this.Appuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.Appuntamento.Controls.Add(this.label15);
            this.Appuntamento.Controls.Add(this.InserireCognomeAppuntamento);
            this.Appuntamento.Controls.Add(this.comboBox3);
            this.Appuntamento.Controls.Add(this.PazienteCognomeAppuntamento);
            this.Appuntamento.Controls.Add(this.InserireNomeAppuntamento);
            this.Appuntamento.Controls.Add(this.PazienteNomeAppuntamento7);
            this.Appuntamento.Controls.Add(this.SeparatoreOreAppuntamento);
            this.Appuntamento.Controls.Add(this.MinutiAppuntamento);
            this.Appuntamento.Controls.Add(this.OraAppuntamento);
            this.Appuntamento.Controls.Add(this.OreAppuntamento);
            this.Appuntamento.Controls.Add(this.AppuntamentoArgomentoAppuntamento);
            this.Appuntamento.Controls.Add(this.AppArgomentoAppuntamento);
            this.Appuntamento.Controls.Add(this.GiornoSelezioneAppuntamento);
            this.Appuntamento.Controls.Add(this.GiornoSelezionaAppuntamento);
            this.Appuntamento.Controls.Add(this.DottoreSelezioneAppuntamento);
            this.Appuntamento.Controls.Add(this.DottoreSelezionaAppuntamento);
            this.Appuntamento.Controls.Add(this.InserireIbanAppuntamento);
            this.Appuntamento.Controls.Add(this.PazienteIbanAppuntamento);
            this.Appuntamento.Controls.Add(this.SalvaAppuntamento);
            this.Appuntamento.Location = new System.Drawing.Point(13, 88);
            this.Appuntamento.Name = "Appuntamento";
            this.Appuntamento.Size = new System.Drawing.Size(660, 392);
            this.Appuntamento.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(17, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(174, 18);
            this.label15.TabIndex = 31;
            this.label15.Text = "Seleziona orario e giorno";
            // 
            // InserireCognomeAppuntamento
            // 
            this.InserireCognomeAppuntamento.AutoSize = true;
            this.InserireCognomeAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireCognomeAppuntamento.Location = new System.Drawing.Point(324, 80);
            this.InserireCognomeAppuntamento.Name = "InserireCognomeAppuntamento";
            this.InserireCognomeAppuntamento.Size = new System.Drawing.Size(135, 18);
            this.InserireCognomeAppuntamento.TabIndex = 46;
            this.InserireCognomeAppuntamento.Text = "Cognome Paziente";
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(197, 24);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(422, 26);
            this.comboBox3.TabIndex = 30;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // PazienteCognomeAppuntamento
            // 
            this.PazienteCognomeAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteCognomeAppuntamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteCognomeAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteCognomeAppuntamento.Location = new System.Drawing.Point(465, 78);
            this.PazienteCognomeAppuntamento.Name = "PazienteCognomeAppuntamento";
            this.PazienteCognomeAppuntamento.Size = new System.Drawing.Size(154, 24);
            this.PazienteCognomeAppuntamento.TabIndex = 45;
            // 
            // InserireNomeAppuntamento
            // 
            this.InserireNomeAppuntamento.AutoSize = true;
            this.InserireNomeAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireNomeAppuntamento.Location = new System.Drawing.Point(47, 80);
            this.InserireNomeAppuntamento.Name = "InserireNomeAppuntamento";
            this.InserireNomeAppuntamento.Size = new System.Drawing.Size(110, 18);
            this.InserireNomeAppuntamento.TabIndex = 44;
            this.InserireNomeAppuntamento.Text = "Nome Paziente";
            // 
            // PazienteNomeAppuntamento7
            // 
            this.PazienteNomeAppuntamento7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteNomeAppuntamento7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteNomeAppuntamento7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteNomeAppuntamento7.Location = new System.Drawing.Point(163, 78);
            this.PazienteNomeAppuntamento7.Name = "PazienteNomeAppuntamento7";
            this.PazienteNomeAppuntamento7.Size = new System.Drawing.Size(155, 24);
            this.PazienteNomeAppuntamento7.TabIndex = 43;
            // 
            // SeparatoreOreAppuntamento
            // 
            this.SeparatoreOreAppuntamento.AutoSize = true;
            this.SeparatoreOreAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SeparatoreOreAppuntamento.Location = new System.Drawing.Point(566, 273);
            this.SeparatoreOreAppuntamento.Name = "SeparatoreOreAppuntamento";
            this.SeparatoreOreAppuntamento.Size = new System.Drawing.Size(13, 18);
            this.SeparatoreOreAppuntamento.TabIndex = 42;
            this.SeparatoreOreAppuntamento.Text = ":";
            // 
            // MinutiAppuntamento
            // 
            this.MinutiAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.MinutiAppuntamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MinutiAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinutiAppuntamento.Location = new System.Drawing.Point(585, 271);
            this.MinutiAppuntamento.Name = "MinutiAppuntamento";
            this.MinutiAppuntamento.Size = new System.Drawing.Size(34, 24);
            this.MinutiAppuntamento.TabIndex = 41;
            // 
            // OraAppuntamento
            // 
            this.OraAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.OraAppuntamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OraAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OraAppuntamento.Location = new System.Drawing.Point(526, 271);
            this.OraAppuntamento.Name = "OraAppuntamento";
            this.OraAppuntamento.Size = new System.Drawing.Size(34, 24);
            this.OraAppuntamento.TabIndex = 40;
            // 
            // OreAppuntamento
            // 
            this.OreAppuntamento.AutoSize = true;
            this.OreAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OreAppuntamento.Location = new System.Drawing.Point(557, 250);
            this.OreAppuntamento.Name = "OreAppuntamento";
            this.OreAppuntamento.Size = new System.Drawing.Size(33, 18);
            this.OreAppuntamento.TabIndex = 39;
            this.OreAppuntamento.Text = "Ore";
            // 
            // AppuntamentoArgomentoAppuntamento
            // 
            this.AppuntamentoArgomentoAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppuntamentoArgomentoAppuntamento.Location = new System.Drawing.Point(20, 233);
            this.AppuntamentoArgomentoAppuntamento.Name = "AppuntamentoArgomentoAppuntamento";
            this.AppuntamentoArgomentoAppuntamento.Size = new System.Drawing.Size(137, 40);
            this.AppuntamentoArgomentoAppuntamento.TabIndex = 38;
            this.AppuntamentoArgomentoAppuntamento.Text = "Argomento dell\'appuntamento";
            this.AppuntamentoArgomentoAppuntamento.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // AppArgomentoAppuntamento
            // 
            this.AppArgomentoAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.AppArgomentoAppuntamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AppArgomentoAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AppArgomentoAppuntamento.Location = new System.Drawing.Point(163, 232);
            this.AppArgomentoAppuntamento.Multiline = true;
            this.AppArgomentoAppuntamento.Name = "AppArgomentoAppuntamento";
            this.AppArgomentoAppuntamento.Size = new System.Drawing.Size(338, 92);
            this.AppArgomentoAppuntamento.TabIndex = 37;
            // 
            // GiornoSelezioneAppuntamento
            // 
            this.GiornoSelezioneAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiornoSelezioneAppuntamento.Location = new System.Drawing.Point(466, 183);
            this.GiornoSelezioneAppuntamento.MinimumSize = new System.Drawing.Size(154, 24);
            this.GiornoSelezioneAppuntamento.Name = "GiornoSelezioneAppuntamento";
            this.GiornoSelezioneAppuntamento.Size = new System.Drawing.Size(154, 24);
            this.GiornoSelezioneAppuntamento.TabIndex = 36;
            // 
            // GiornoSelezionaAppuntamento
            // 
            this.GiornoSelezionaAppuntamento.AutoSize = true;
            this.GiornoSelezionaAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GiornoSelezionaAppuntamento.Location = new System.Drawing.Point(421, 186);
            this.GiornoSelezionaAppuntamento.Name = "GiornoSelezionaAppuntamento";
            this.GiornoSelezionaAppuntamento.Size = new System.Drawing.Size(39, 18);
            this.GiornoSelezionaAppuntamento.TabIndex = 35;
            this.GiornoSelezionaAppuntamento.Text = "Data";
            // 
            // DottoreSelezioneAppuntamento
            // 
            this.DottoreSelezioneAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DottoreSelezioneAppuntamento.FormattingEnabled = true;
            this.DottoreSelezioneAppuntamento.Location = new System.Drawing.Point(163, 183);
            this.DottoreSelezioneAppuntamento.Name = "DottoreSelezioneAppuntamento";
            this.DottoreSelezioneAppuntamento.Size = new System.Drawing.Size(155, 26);
            this.DottoreSelezioneAppuntamento.TabIndex = 34;
            // 
            // DottoreSelezionaAppuntamento
            // 
            this.DottoreSelezionaAppuntamento.AutoSize = true;
            this.DottoreSelezionaAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DottoreSelezionaAppuntamento.Location = new System.Drawing.Point(17, 186);
            this.DottoreSelezionaAppuntamento.Name = "DottoreSelezionaAppuntamento";
            this.DottoreSelezionaAppuntamento.Size = new System.Drawing.Size(140, 18);
            this.DottoreSelezionaAppuntamento.TabIndex = 33;
            this.DottoreSelezionaAppuntamento.Text = "Selezionare Dottore";
            // 
            // InserireIbanAppuntamento
            // 
            this.InserireIbanAppuntamento.AutoSize = true;
            this.InserireIbanAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InserireIbanAppuntamento.Location = new System.Drawing.Point(61, 128);
            this.InserireIbanAppuntamento.Name = "InserireIbanAppuntamento";
            this.InserireIbanAppuntamento.Size = new System.Drawing.Size(160, 18);
            this.InserireIbanAppuntamento.TabIndex = 32;
            this.InserireIbanAppuntamento.Text = "Codice fiscale paziente";
            // 
            // PazienteIbanAppuntamento
            // 
            this.PazienteIbanAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.PazienteIbanAppuntamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PazienteIbanAppuntamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PazienteIbanAppuntamento.Location = new System.Drawing.Point(227, 126);
            this.PazienteIbanAppuntamento.Name = "PazienteIbanAppuntamento";
            this.PazienteIbanAppuntamento.Size = new System.Drawing.Size(392, 24);
            this.PazienteIbanAppuntamento.TabIndex = 31;
            // 
            // SalvaAppuntamento
            // 
            this.SalvaAppuntamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.SalvaAppuntamento.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SalvaAppuntamento.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SalvaAppuntamento.Location = new System.Drawing.Point(281, 349);
            this.SalvaAppuntamento.Name = "SalvaAppuntamento";
            this.SalvaAppuntamento.Size = new System.Drawing.Size(100, 23);
            this.SalvaAppuntamento.TabIndex = 26;
            this.SalvaAppuntamento.Text = "Salva";
            this.SalvaAppuntamento.UseVisualStyleBackColor = false;
            this.SalvaAppuntamento.Click += new System.EventHandler(this.SalvaAppuntamento_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(13, 88);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(660, 392);
            this.panel2.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(144, 141);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 111);
            this.button2.TabIndex = 1;
            this.button2.Text = "Modifica un dottore";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(368, 141);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 111);
            this.button1.TabIndex = 0;
            this.button1.Text = "Aggiungi un dottore";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button4);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.dateTimePicker1);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Location = new System.Drawing.Point(13, 88);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(660, 392);
            this.panel3.TabIndex = 5;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(164, 231);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(155, 143);
            this.button3.TabIndex = 29;
            this.button3.Text = "Licenzia";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(420, 302);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 72);
            this.button4.TabIndex = 28;
            this.button4.Text = "Salva";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(515, 178);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(122, 24);
            this.textBox5.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(386, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 18);
            this.label7.TabIndex = 26;
            this.label7.Text = "Specializzazione";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(165, 177);
            this.dateTimePicker1.MinimumSize = new System.Drawing.Size(154, 24);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(154, 24);
            this.dateTimePicker1.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(54, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 18);
            this.label6.TabIndex = 24;
            this.label6.Text = "Data di nascita";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(165, 134);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(154, 24);
            this.textBox3.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(85, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 18);
            this.label4.TabIndex = 22;
            this.label4.Text = "Cognome";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(165, 84);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(154, 24);
            this.textBox4.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(110, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 18);
            this.label5.TabIndex = 20;
            this.label5.Text = "Nome";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(511, 134);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(34, 24);
            this.textBox2.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(413, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 18);
            this.label3.TabIndex = 18;
            this.label3.Text = "Orario di fine";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(511, 84);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(34, 24);
            this.textBox1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(402, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Orario di inizio";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Seleziona Dottore";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(165, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(380, 26);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.textBox6);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.dateTimePicker2);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.textBox7);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.textBox10);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Location = new System.Drawing.Point(13, 88);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(660, 392);
            this.panel4.TabIndex = 6;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(77)))), ((int)(((byte)(4)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(285, 286);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(90, 72);
            this.button5.TabIndex = 40;
            this.button5.Text = "Salva";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(498, 196);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(122, 24);
            this.textBox6.TabIndex = 39;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(369, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 18);
            this.label8.TabIndex = 38;
            this.label8.Text = "Specializzazione";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(148, 195);
            this.dateTimePicker2.MinimumSize = new System.Drawing.Size(154, 24);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(154, 24);
            this.dateTimePicker2.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(37, 198);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 18);
            this.label9.TabIndex = 36;
            this.label9.Text = "Data di nascita";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(148, 122);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(154, 24);
            this.textBox7.TabIndex = 35;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(68, 124);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 18);
            this.label10.TabIndex = 34;
            this.label10.Text = "Cognome";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(148, 41);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(154, 24);
            this.textBox8.TabIndex = 33;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(93, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 18);
            this.label11.TabIndex = 32;
            this.label11.Text = "Nome";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(494, 122);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(34, 24);
            this.textBox9.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(396, 124);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 18);
            this.label12.TabIndex = 30;
            this.label12.Text = "Orario di fine";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(171)))), ((int)(((byte)(96)))));
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(494, 41);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(34, 24);
            this.textBox10.TabIndex = 29;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(385, 43);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(103, 18);
            this.label13.TabIndex = 28;
            this.label13.Text = "Orario di inizio";
            // 
            // orologio
            // 
            this.orologio.Enabled = true;
            this.orologio.Tick += new System.EventHandler(this.orologio_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(232)))), ((int)(((byte)(204)))));
            this.ClientSize = new System.Drawing.Size(686, 495);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Appuntamento);
            this.Controls.Add(this.Calendario);
            this.Controls.Add(this.Aggiungi);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.RightToLeftLayout = true;
            this.Text = " ";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Aggiungi.ResumeLayout(false);
            this.Aggiungi.PerformLayout();
            this.Calendario.ResumeLayout(false);
            this.Calendario.PerformLayout();
            this.Appuntamento.ResumeLayout(false);
            this.Appuntamento.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel Aggiungi;
        private System.Windows.Forms.Label InserireCognomeAggiungi;
        private System.Windows.Forms.TextBox PazienteCognomeAggiungi;
        private System.Windows.Forms.Label InserireNomeAggiungi;
        private System.Windows.Forms.TextBox PazienteNomeAggiungi;
        private System.Windows.Forms.DateTimePicker GiornoSelezioneAggiungi;
        private System.Windows.Forms.Label GiornoSelezionaAggiungi;
        private System.Windows.Forms.ComboBox DottoreSelezioneAggiungi;
        private System.Windows.Forms.Label DotoreSelezioneAggiungi;
        private System.Windows.Forms.Label InserireIbanAggiungi;
        private System.Windows.Forms.TextBox PazienteCodiceFiscaleAggiungi;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BottoneSalvaAggiungi;
        private System.Windows.Forms.Label AppuntamentoArgomentoAggiugni;
        private System.Windows.Forms.TextBox AppArgomentoAggiungi;
        private System.Windows.Forms.Panel Calendario;
        private System.Windows.Forms.Label SelezionaGiornoCalendario;
        private System.Windows.Forms.DateTimePicker GiornoCalendario;
        private System.Windows.Forms.Button VaiAppuntamenti;
        private System.Windows.Forms.Label ListaAppuntamentiAggiugni;
        private System.Windows.Forms.Panel Appuntamento;
        private System.Windows.Forms.TextBox MinutiAggiungi;
        private System.Windows.Forms.TextBox OraAggiungi;
        private System.Windows.Forms.Label OreAggiungi;
        private System.Windows.Forms.Button SalvaAppuntamento;
        private System.Windows.Forms.Label SeparatoreOreAggiungi;
        private System.Windows.Forms.Label InserireCognomeAppuntamento;
        private System.Windows.Forms.TextBox PazienteCognomeAppuntamento;
        private System.Windows.Forms.Label InserireNomeAppuntamento;
        private System.Windows.Forms.TextBox PazienteNomeAppuntamento7;
        private System.Windows.Forms.Label SeparatoreOreAppuntamento;
        private System.Windows.Forms.TextBox MinutiAppuntamento;
        private System.Windows.Forms.TextBox OraAppuntamento;
        private System.Windows.Forms.Label OreAppuntamento;
        private System.Windows.Forms.Label AppuntamentoArgomentoAppuntamento;
        private System.Windows.Forms.TextBox AppArgomentoAppuntamento;
        private System.Windows.Forms.DateTimePicker GiornoSelezioneAppuntamento;
        private System.Windows.Forms.Label GiornoSelezionaAppuntamento;
        private System.Windows.Forms.ComboBox DottoreSelezioneAppuntamento;
        private System.Windows.Forms.Label DottoreSelezionaAppuntamento;
        private System.Windows.Forms.Label InserireIbanAppuntamento;
        private System.Windows.Forms.TextBox PazienteIbanAppuntamento;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Timer orologio;
        private System.Windows.Forms.Label clockLbl;
        private System.Windows.Forms.Label dateLbl;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button11;
    }
}

