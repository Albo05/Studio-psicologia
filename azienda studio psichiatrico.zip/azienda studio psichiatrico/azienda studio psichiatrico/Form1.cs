﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace azienda_studio_psichiatrico
{
    public partial class Form1 : Form
    {

        //controllare lunghezza iban, nome e cognome all'inserimento per ottenere max 58 caratteri (iban 27)

        List<doc> dottori = new List<doc>();
        List<paz> pazienti = new List<paz>();
        List<app> appuntamenti = new List<app>();

        public Form1()
        {
            InitializeComponent();
            if(File.Exists("pazienti.cheSchifoIFileBinari"))
                caricaPazientiOrdinati();
            if(File.Exists("appuntamenti.cheSchifoIFileBinari"))
                caricaAppuntamentiOrdinati();
            if(File.Exists("dottori.cheSchifoIFileBinari"))
                caricaDottoriOrdinati();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // OROLOGIO
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void orologio_Tick(object sender, EventArgs e)
        {
            string ore = "";
            ore += DateTime.Now.Hour.ToString();
            ore += " : ";
            ore += DateTime.Now.Minute.ToString();
            clockLbl.Text = ore;
            dateLbl.Text = DateTime.Now.ToLongDateString();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // AGGIUNGERE UN APPUNTAMENTO
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void aggiungiAppuntamentoMain()
        {
            if (elementiNonValidiAggiungi())
            {
                MessageBox.Show("Uno o più parametri inseriti non sono corretti");
                return;
            }
            paz pazienteAppuntamentoDaAggiungere = new paz(PazienteNomeAggiungi.Text.ToString(), PazienteCognomeAggiungi.Text.ToString(), PazienteCodiceFiscaleAggiungi.Text.ToString());
            doc dottoreAppuntamentoDaAggiungere = dottori[DottoreSelezioneAggiungi.SelectedIndex];
            double ore = Convert.ToDouble(OraAggiungi.Text) + (Convert.ToDouble(MinutiAggiungi.Text) / 100);
            if(dottoreLibero(dottoreAppuntamentoDaAggiungere, GiornoSelezioneAggiungi.Value, ore) && pazienteLibero(pazienteAppuntamentoDaAggiungere, GiornoSelezioneAggiungi.Value, ore) && dottoreAppuntamentoDaAggiungere.Assunto)
            {
                SalvaAppuntamenti(new app(pazienteAppuntamentoDaAggiungere, dottoreAppuntamentoDaAggiungere, GiornoSelezioneAggiungi.Value, AppArgomentoAggiungi.Text, ore));
                caricaAppuntamentiOrdinati();
                pazienteEsiste(pazienteAppuntamentoDaAggiungere);
                caricaPazientiOrdinati();
            }
        }

        private bool dottoreLibero(doc dottore, DateTime giorno, double ore)
        {
            if (ore > dottore.OraInizio && ore < dottore.OraFine - 0.15)
            {
                foreach (app a in appuntamenti)
                {
                    if (a.data == giorno)
                    {
                        if (((a.ore < ore && aggiungi15Min(a.ore) > ore) || (ore < a.ore && aggiungi15Min(ore) > a.ore)) && a.dottore == dottore)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        }

        private bool pazienteLibero(paz paziente, DateTime giorno, double ore)
        {
            foreach (app a in appuntamenti)
            {
                if (a.data == giorno)
                {
                    if (((a.ore < ore && aggiungi15Min(a.ore) > ore) || (ore < a.ore && aggiungi15Min(ore) > a.ore)) && a.paziente.codiceFiscale == paziente.codiceFiscale)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public double aggiungi15Min(double ore)
        {
            ore += 0.15;
            if(ore%1 >= 0.60)
            {
                ore -= 0.60;
                ore += 1;
                if(ore >= 24)
                    ore -= 24;
            }
            return ore;
        }

        public bool elementiNonValidiAggiungi() 
        { 
            if (PazienteNomeAggiungi.Text.ToString().Trim() == null)
                return true;
            if (PazienteCognomeAggiungi.Text.ToString().Trim() == null)
                return true;
            if (PazienteCodiceFiscaleAggiungi.Text.ToString().Trim() == null)
                return true;
            if (AppArgomentoAggiungi.Text.ToString().Trim() == null)
                return true;
            if (OraAggiungi.Text.ToString().Trim() == null || !double.TryParse(OraAggiungi.Text.ToString(), out double a))
                return true;
            if (MinutiAggiungi.Text.ToString().Trim() == null || !double.TryParse(OraAggiungi.Text.ToString(), out a))
                return true;
            return false;
        }

        private void pazienteEsiste(paz paziente)
        {
            bool presente = false;
            foreach (paz a in pazienti)
                if(a == paziente)
                    presente = true;
            if (!presente)
                SalvaPazienti(paziente);
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // AGGIUNGERE UN DOTTORE
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void aggiungiDottoreMain()
        {
            if (elementiNonValidiDottore())
            {
                MessageBox.Show("Uno o più parametri inseriti non sono corretti");
                return;
            }
            doc daAggiungere = new doc(textBox8.Text.ToString(), textBox7.Text.ToString(), dateTimePicker2.Value, Convert.ToDouble(textBox10.Text.ToString()), Convert.ToDouble(textBox9.Text.ToString()), textBox6.Text.ToString(), true);
            if (esiste(daAggiungere))
            {
                MessageBox.Show("Il dottore inserito è già stato assunto all'interno di questo studio");
                return;
            }
            SalvaDottori(daAggiungere);
            caricaDottoriOrdinati();
        }

        private bool esiste(doc dottore)
        {
            bool esiste = false;
            foreach (doc a in dottori)
                if(a.Nome == dottore.Nome && a.Cognome == dottore.Cognome)
                    esiste = true;
            return esiste;
        }

        public bool elementiNonValidiDottore()
        {
            if (dateTimePicker2.Value.Year > DateTime.Now.Year - 18)
                return true;
            if (textBox6.Text.ToString().Trim().Length == 0)
                return true;
            if (textBox9.Text.ToString().Trim().Length == 0 || !double.TryParse(textBox9.Text.ToString(), out double a))
                return true;
            if (textBox10.Text.ToString().Trim().Length == 0 || !double.TryParse(textBox10.Text.ToString(), out a))
                return true;
            if (textBox8.Text.ToString().Trim().Length == 0)
                return true;
            if (textBox7.Text.ToString().Trim().Length == 0)
                return true;
            return false;
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // CARICARE PAZIENTI
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void caricaPazientiOrdinati()
        {
            pazienti.Clear();
            using (FileStream file = new FileStream("pazienti.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryReader lettore = new BinaryReader(file);
                do
                {
                    file.Seek(lettore.ReadInt32(), SeekOrigin.Begin);
                    pazienti.Add(paz.nuovo(lettore.ReadString()));
                    int pos = Convert.ToInt32(file.Position);
                    if (lettore.ReadInt32() == 0)
                    {
                        return;
                    }
                    file.Seek(pos, SeekOrigin.Begin);
                } while (1 == 1) ;
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // SALVARE UN PAZIENTE
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        void SalvaPazienti(paz daSalvare)
        {
            using (FileStream file = new FileStream("pazienti.cheSchifoIFileBinari", FileMode.OpenOrCreate))
            {
                BinaryWriter scrittore = new BinaryWriter(file);
                if (file.Length > 0)
                {
                    BinaryReader lettore = new BinaryReader(file);
                    bool inserito = false;
                    paz prelevato = null;
                    int puntatoreLetto = 0;
                    int byteLetto = 0;
                    do
                    {
                        byteLetto = Convert.ToInt32(file.Position);
                        puntatoreLetto = lettore.ReadInt32();
                        if (puntatoreLetto != 0)
                        {
                            file.Seek(puntatoreLetto, SeekOrigin.Begin);
                            prelevato = paz.nuovo(lettore.ReadString());
                        }
                        if (puntatoreLetto == 0 || prelevato.CompareTo(daSalvare) == -1)
                        {
                            file.Seek(byteLetto, SeekOrigin.Begin);
                            scrittore.Write(Convert.ToInt32(file.Length));
                            file.Seek(0, SeekOrigin.End);
                            scrittore.Write(daSalvare.ToString().PadLeft(100));
                            scrittore.Write(puntatoreLetto);
                            inserito = true;
                        }
                    } while (!inserito);
                }
                else
                {
                    scrittore.Write(4);
                    scrittore.Write(daSalvare.ToString());
                    scrittore.Write(0);
                }
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // CARICARE APPUNTAMENTI
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void caricaAppuntamentiOrdinati()
        {
            appuntamenti.Clear();
            using (FileStream file = new FileStream("appuntamenti.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryReader lettore = new BinaryReader(file);
                do
                {
                    file.Seek(lettore.ReadInt32(), SeekOrigin.Begin);
                    appuntamenti.Add(app.nuovo(lettore.ReadString()));
                    int pos = Convert.ToInt32(file.Position);
                    if (lettore.ReadInt32() == 0)
                    {
                        return;
                    }
                    file.Seek(pos, SeekOrigin.Begin);
                } while (1 == 1);
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // SALVARE UN APPUNTAMENTO
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        void SalvaAppuntamenti(app daSalvare)
        {
            using (FileStream file = new FileStream("appuntamenti.cheSchifoIFileBinari", FileMode.OpenOrCreate))
            {
                BinaryWriter scrittore = new BinaryWriter(file);
                if (file.Length > 0)
                {
                    BinaryReader lettore = new BinaryReader(file);
                    bool inserito = false;
                    app prelevato = null;
                    int puntatoreLetto = 0;
                    int byteLetto = 0;
                    do
                    {
                        byteLetto = Convert.ToInt32(file.Position);
                        puntatoreLetto = lettore.ReadInt32();
                        if (puntatoreLetto != 0)
                        {
                            file.Seek(puntatoreLetto, SeekOrigin.Begin);
                            prelevato = app.nuovo(lettore.ReadString());
                        }
                        if (puntatoreLetto == 0 || prelevato.CompareTo(daSalvare) == -1)
                        {
                            file.Seek(byteLetto, SeekOrigin.Begin);
                            scrittore.Write(Convert.ToInt32(file.Length));
                            file.Seek(0, SeekOrigin.End);
                            scrittore.Write(daSalvare.ToString().PadLeft(100));
                            scrittore.Write(puntatoreLetto);
                            inserito = true;
                        }
                    } while (!inserito);
                }
                else
                {
                    scrittore.Write(4);
                    scrittore.Write(daSalvare.ToString());
                    scrittore.Write(0);
                }
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // CARICARE DOTTORI
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void caricaDottoriOrdinati()
        {
            dottori.Clear();
            using (FileStream file = new FileStream("dottori.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryReader lettore = new BinaryReader(file);
                do
                {
                    file.Seek(lettore.ReadInt32(), SeekOrigin.Begin);
                    dottori.Add(doc.nuovo(lettore.ReadString()));
                    int pos = Convert.ToInt32(file.Position);
                    if (lettore.ReadInt32() == 0)
                    {
                        return;
                    }
                    file.Seek(pos, SeekOrigin.Begin);
                } while (1 == 1);
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // SALVARE UN DOTTORE
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        void SalvaDottori(doc daSalvare)
        {
            using (FileStream file = new FileStream("dottori.cheSchifoIFileBinari", FileMode.OpenOrCreate))
            {
                BinaryWriter scrittore = new BinaryWriter(file);
                if (file.Length > 0)
                {
                    BinaryReader lettore = new BinaryReader(file);
                    bool inserito = false;
                    doc prelevato = null;
                    int puntatoreLetto = 0;
                    int byteLetto = 0;
                    do
                    {
                        byteLetto = Convert.ToInt32(file.Position);
                        puntatoreLetto = lettore.ReadInt32();
                        if (puntatoreLetto != 0)
                        {
                            file.Seek(puntatoreLetto, SeekOrigin.Begin);
                            prelevato = doc.nuovo(lettore.ReadString());
                        }
                        if (puntatoreLetto == 0 || prelevato.CompareTo(daSalvare) == -1)
                        {
                            file.Seek(byteLetto, SeekOrigin.Begin);
                            scrittore.Write(Convert.ToInt32(file.Length));
                            file.Seek(0, SeekOrigin.End);
                            scrittore.Write(daSalvare.ToString().PadLeft(100));
                            scrittore.Write(puntatoreLetto);
                            inserito = true;
                        }
                    } while (!inserito);
                }
                else
                {
                    scrittore.Write(4);
                    scrittore.Write(daSalvare.ToString());
                    scrittore.Write(0);
                }
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // FUNZIONI VARIE DI CARICAMENTO DATI IN OGGETTI
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        public void caricaDottori(ComboBox cb)
        {
            string s = "";
            for (int i = 0; i < dottori.Count; i++)
            {
                s = $"{dottori[i].Nome} {dottori[i].Cognome} -> {dottori[i].Specializzazione}";
                cb.Items.Add(s);
            }
        }

        public void caricaAppuntamentiData(DateTime dt, Label l)
        {
            List<app> dataGiusta = new List<app>();
            foreach (app a in appuntamenti)
                if(a.data == dt)
                    dataGiusta.Add(a);
            string appuntamentiFormattati = "";
            foreach (app a in dataGiusta)
                appuntamentiFormattati += $"{a.ore} {a.paziente.nome} {a.paziente.cognome}, medico: {a.dottore.Nome} {a.dottore.Cognome} -> {a.argomento}\n\n";
            l.Text = appuntamentiFormattati;
        }

        public void caricaAppuntamentiDottore(ComboBox cb, Label l)
        {
            List<app> dottoreGiusto = new List<app>();
            foreach (app a in appuntamenti)
                if ($"{a.dottore.Nome} {a.dottore.Cognome} -> {a.dottore.Specializzazione}" == Convert.ToString(cb.SelectedIndex))
                    dottoreGiusto.Add(a);
            string appuntamentiFormattati = "";
            foreach (app a in dottoreGiusto)
                appuntamentiFormattati += $"{a.ore} {a.paziente.nome} {a.paziente.cognome}, medico: {a.dottore.Nome} {a.dottore.Cognome} -> {a.argomento}\n\n";
            l.Text = appuntamentiFormattati;
        }

        public void caricaAppuntamentiTutti(ComboBox cb)
        {
            string s = "";
            foreach (app a in appuntamenti)
            {
                s = $"{a.ore} {a.paziente.nome} {a.paziente.cognome}, medico: {a.dottore.Nome} {a.dottore.Cognome} -> {a.argomento}";
                cb.Items.Add(s);
            }
        }

        public int trovaPosizioneBinariaAppuntamenti(int index)
        {
            using(FileStream fs = new FileStream("appuntamenti.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryReader br = new BinaryReader(fs);
                int puntatore = 0;
                app appoggio;
                bool trovato = false;
                do
                {
                    puntatore = br.ReadInt32();
                    fs.Seek(puntatore, SeekOrigin.Begin);
                    appoggio = app.nuovo(br.ReadString());
                    if (appoggio == appuntamenti[index])
                        return puntatore; trovato = true;
                } while (!trovato);
                return Convert.ToInt32(fs.Length);
            }
        }

        public int trovaPosizioneBinariaDottori(int index)
        {
            using (FileStream fs = new FileStream("dottori.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryReader br = new BinaryReader(fs);
                int puntatore = 0;
                app appoggio;
                bool trovato = false;
                do
                {
                    puntatore = br.ReadInt32();
                    fs.Seek(puntatore, SeekOrigin.Begin);
                    appoggio = app.nuovo(br.ReadString());
                    if (appoggio == appuntamenti[index])
                        return puntatore; trovato = true;
                } while (!trovato);
                return Convert.ToInt32(fs.Length);
            }
        }



        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        // BOTTONI  
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void BottoneSalvaAggiungi_Click(object sender, EventArgs e)
        {
            aggiungiAppuntamentoMain();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = true;
            Calendario.Visible = false;
            Appuntamento.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = false;
            caricaDottori(DottoreSelezioneAggiungi);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = false;
            Calendario.Visible = true;
            Appuntamento.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = false;
            caricaDottori(comboBox2);
        }

        private void VaiAppuntamenti_Click(object sender, EventArgs e)
        {
            caricaAppuntamentiData(GiornoCalendario.Value, ListaAppuntamentiAggiugni);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            caricaAppuntamentiDottore(comboBox2, ListaAppuntamentiAggiugni);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = false;
            Calendario.Visible = false;
            Appuntamento.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = false;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            PazienteNomeAppuntamento7.Text = appuntamenti[comboBox3.SelectedIndex].paziente.nome.ToString();
            PazienteCognomeAppuntamento.Text = appuntamenti[comboBox3.SelectedIndex].paziente.cognome.ToString();
            PazienteIbanAppuntamento.Text = appuntamenti[comboBox3.SelectedIndex].paziente.codiceFiscale.ToString();
            caricaDottori(DottoreSelezioneAppuntamento);
            for (int i = 0; i < dottori.Count; i++)
                if (dottori[i] == appuntamenti[comboBox3.SelectedIndex].dottore)
                    DottoreSelezioneAppuntamento.SelectedIndex = i;
            GiornoSelezioneAppuntamento.Value = appuntamenti[comboBox3.SelectedIndex].data;
            AppArgomentoAppuntamento.Text = appuntamenti[comboBox3.SelectedIndex].argomento.ToString();
            int minuti = Convert.ToInt32((appuntamenti[comboBox3.SelectedIndex].ore % 1) * 100);
            MinutiAppuntamento.Text = minuti.ToString();
            int ore = Convert.ToInt32(((appuntamenti[comboBox3.SelectedIndex].ore * 100) - minuti ) /100);
            OreAppuntamento.Text = ore.ToString();
        }

        private void SalvaAppuntamento_Click(object sender, EventArgs e)
        {
            int dove = trovaPosizioneBinariaAppuntamenti(comboBox3.SelectedIndex);
            paz pazienteAppuntamentoDaModificare = new paz(PazienteNomeAppuntamento7.Text.ToString(), PazienteCognomeAppuntamento.Text.ToString(), PazienteIbanAppuntamento.Text.ToString());
            doc dottoreAppuntamentoDaModificare = dottori[DottoreSelezioneAppuntamento.SelectedIndex];
            double ore = Convert.ToDouble(OraAppuntamento.Text) + (Convert.ToDouble(MinutiAppuntamento.Text) / 100);
            app nuovo = new app(pazienteAppuntamentoDaModificare, dottoreAppuntamentoDaModificare, GiornoSelezioneAppuntamento.Value, AppArgomentoAppuntamento.Text, ore);
            using(FileStream fs = new FileStream("appuntamenti.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryWriter br = new BinaryWriter(fs);
                fs.Seek(dove, SeekOrigin.Begin);
                br.Write(nuovo.ToString().PadLeft(100));
            }
            caricaAppuntamentiOrdinati();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = false;
            Calendario.Visible = false;
            Appuntamento.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = false;
            Calendario.Visible = false;
            Appuntamento.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;
            panel2.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            aggiungiDottoreMain();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Aggiungi.Visible = false;
            Calendario.Visible = false;
            Appuntamento.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;
            panel2.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            doc selezionato = dottori[comboBox1.SelectedIndex];
            textBox4.Text = selezionato.Nome;
            textBox3.Text = selezionato.Cognome;
            dateTimePicker1.Value = selezionato.Nascita;
            textBox1.Text = selezionato.OraInizio.ToString();
            textBox2.Text = selezionato.OraInizio.ToString();
            textBox5.Text = selezionato.Specializzazione;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            doc daInserire = new doc(textBox4.Text, textBox3.Text, dateTimePicker1.Value, Convert.ToDouble(textBox1.Text), Convert.ToDouble(textBox2.Text), textBox5.Text, true);
            int dove = trovaPosizioneBinariaDottori(comboBox1.SelectedIndex);
            using (FileStream fs = new FileStream("dottori.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryWriter br = new BinaryWriter(fs);
                fs.Seek(dove, SeekOrigin.Begin);
                br.Write(daInserire.ToString().PadLeft(100));
            }
            caricaDottoriOrdinati();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dottori[comboBox1.SelectedIndex].Assunto = false;
            doc daInserire = dottori[comboBox1.SelectedIndex];
            int dove = trovaPosizioneBinariaDottori(comboBox1.SelectedIndex);
            using (FileStream fs = new FileStream("dottori.cheSchifoIFileBinari", FileMode.Open))
            {
                BinaryWriter br = new BinaryWriter(fs);
                fs.Seek(dove, SeekOrigin.Begin);
                br.Write(daInserire.ToString().PadLeft(100));
            }
            caricaDottoriOrdinati();
        }
    }
}
